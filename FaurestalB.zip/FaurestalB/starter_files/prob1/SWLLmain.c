/*Copyright (c) 2016 CareerMonk Publications and others.
#E-Mail            : info@careermonk.com 
#Creation Date     : 2008-01-10 06:15:46 
#Created by        : Narasimha Karumanchi
#Book Title        : Data Structures And Algorithms Made Easy
#Warranty          : This software is provided "as is" without any 
#                    warranty; without even the implied warranty of 
#                    merchantability or fitness for a particular purpose.*/

/**
 * SWLLmain.c - Source code for program to test the Queue ADT
 *
 * Author: Bendjy Faurestal  (bernad3@pdx.edu)
 * Date: 8-Nov-2021
 *
 * This is the main program that let user input numbers and perform the RPN calculation
 */


#include"SWLL.h"

int main()
{
    int i = 0,result;
    char ch;  
    int quit = 0;
    struct Stack *stk = createStack();
    while (!quit) {
    printf("Enter a RPN expression: ");
        do {
        scanf(" %c", &ch);
        //printf( " %c \n ", ch);
        if(isdigit(ch)){
          push(stk,(int)ch - 48); // to convert ascii 
          // printf("%d \n ", peek(stk));
        }
        else
        {
            int val1 = pop(stk);
            int val2 = pop(stk);
    
            switch(ch){
            case '+': result = val1 + val2; break;
            case '-': result = val2 - val1; break;
            case '*': result = val1 * val2; break;
            case '/': result = val2 / val1; break;
            case '=':printf("Value of expression: %d \n",result);break;
            default: quit= 1;
            }
            if (ch != '='){
            //printf(" %d\n", result);
            push(stk,result);
        }
        }
    } while (ch != '=' && quit == 0);
    }
    

    deleteStack(stk);
    return 0;
}
