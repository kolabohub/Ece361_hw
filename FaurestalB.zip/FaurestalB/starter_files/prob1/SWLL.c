/*Copyright (c) 2016 CareerMonk Publications and others.
#E-Mail            : info@careermonk.com 
#Creation Date     : 2008-01-10 06:15:46 
#Created by        : Narasimha Karumanchi 
#Book Title        : Data Structures And Algorithms Made Easy
#Warranty          : This software is provided "as is" without any 
#                    warranty; without even the implied warranty of 
#                    merchantability or fitness for a particular purpose.*/

/**
 * SWLLmain.c - Source code for program to test the Queue ADT
 *
 * Author: Bendjy Faurestal  (bernad3@pdx.edu)
 * Date: 8-Nov-2021
 *
 * This is a program that let user input numbers and perform the RPN calculation
 * this includes the fucntions 
 */

#include"SWLL.h"


void push(struct Stack *stk, int data){
    struct ListNode *temp;
    temp = malloc(sizeof(struct ListNode));
    if(!temp){
        printf("\nStack/Heap overflow");
        return;
    }
    temp->data = data;
    temp->next = stk->top;
    stk->top = temp;
    stk->size++;
}

struct Stack *createStack(){
    struct Stack *stk;
    stk = malloc(sizeof(struct Stack));
    stk->top = NULL;
    stk->size = 0;
    return stk;
}

int size(struct Stack *stk){
    // NOTE: we could improve the performance of the size function by adding a size variable in the
    // stack structure and update it when doing push/pop operations
    return stk->size;
}

int isEmpty(struct Stack *stk){
    return stk->top == NULL;
}

int pop(struct Stack *stk){
    int data;
    struct ListNode *temp;
    if(isEmpty(stk))   
        return INT_MIN;
    temp = stk->top;
    stk->top = stk->top->next;
    data = temp->data;
    free(temp);
    stk->size--;
    return data;
}

int peek(struct Stack * stk){
    if(isEmpty(stk))  
        return INT_MIN;
    return stk->top->data;
}

void deleteStack(struct Stack *stk){
    struct ListNode *temp, *p;
    p = stk->top;
    while( p) {
        temp = p->next;
        p = p->next;
        free(temp);
    }
    stk->size = 0;
    free(stk);
}
