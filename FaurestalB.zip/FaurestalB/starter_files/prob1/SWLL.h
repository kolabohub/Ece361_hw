//#ifndef SWLL_H
//#define SWLL_H
#ifndef SWLL_H
#define SWLL_H

#include <stdio.h>
#include <stdlib.h>
#include <limits.h>
#include <ctype.h>

struct ListNode{
    int data;
    struct ListNode *next;
};

struct Stack{
    struct ListNode *top;
    int size;
};

struct Stack *createStack();
void push(struct Stack *stk, int data);
int size(struct Stack *stk);
int isEmpty(struct Stack *stk);
int pop(struct Stack *stk);
int peek(struct Stack * stk);
void deleteStack(struct Stack *stk);

#endif