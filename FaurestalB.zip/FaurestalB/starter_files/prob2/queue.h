#ifndef __QUEUE_ADT__
#define __QUEUE_ADT__

#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <errno.h>
#include <stdio.h>

#define QUEUE_SIZE 10

// function prototypes
void initQueue(void);
int isEmpty(void);
int isFull(void);
int enqueue(char d);
int dequeue(void);
int listQueueContents(void);

#endif