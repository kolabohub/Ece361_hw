
/**
 * queue.c - Source code for program to test the Queue ADT
 *
 * Author: Bendjy Faurestal  (bernad3@pdx.edu)
 * Date: 8-Nov-2021
 *
 * This is the main program that encapsulates the functionality of a queue
 */
#include "queue.h"
char myQueue[QUEUE_SIZE];
int front = -1;
int rear = -1;
// add en entry
void initQueue()
{
    int i;
    for (i = 0; i < QUEUE_SIZE; ++i)
        myQueue[i] = 0;
    front = rear = -1;
}
int enqueue(char d)
{
    if (isFull())
    {
        return 0;
    }
    else
    {
        if (front == -1)
            front = 0;
        rear = (rear + 1) % QUEUE_SIZE;
        myQueue[rear] = d;
        return 1;
    }
}

// remove an entry
int dequeue(void)
{
    char d;
    if (isEmpty())
    {
        // queue is empty
        return 0;
    }
    else
    {
       
        // reset the queue
        d = myQueue[front];
        if (front == rear)
        {
            front = -1;
            rear = -1;
        }
        else
        {
            // delete one entry at the front
            front = (front + 1) % QUEUE_SIZE;
        }
        return d;
    }
}

// Check if the queue is full
int isFull(void)
{
    if ((front == rear + 1) || (front == 0 && rear == QUEUE_SIZE - 1))
        return 1;
    else
        return 0;
}

// Check if the queue is empty
int isEmpty(void)
{
    if (front == -1)
        return 1;
    else
        return 0;
}

// Display the queue
int listQueueContents(void)
{
    if (isEmpty())
    {
        return 0;
    }
    else
    {
        int walkOverQueue;
        int count = 0;
        for (walkOverQueue = front; walkOverQueue != rear; walkOverQueue = (walkOverQueue + 1) % QUEUE_SIZE)
        {
            printf("%c\n", myQueue[walkOverQueue]);
            count++;
        }
        printf("%c\n", myQueue[walkOverQueue]);

        return count+1;
    }
}
